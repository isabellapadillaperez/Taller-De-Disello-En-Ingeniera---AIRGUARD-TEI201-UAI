#include <Arduino.h>
#include <U8g2lib.h>
#include <Wire.h>

// Constructor específico para pantallas OLED de 1.3" I2C (SH1106) en ESP32
// [page buffer, tamaño completo 128x64, hardware I2C en pines 21 y 22]
U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE, /* clock=*/ 22, /* data=*/ 21);

const int PIN_MQ135 = 34; // Pin del sensor (divisor de tensión)

const float V_REF = 3.3;
const float RL = 10.0;
float Ro = 10.0;

void setup() {
  Serial.begin(115200);

  // Inicializar bus I2C y pantalla
  Wire.begin(21, 22);
  u8g2.begin();

  // Pantalla de Bienvenida AIRGUARD
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_ncenB12_tr);
  u8g2.drawStr(12, 22, "AIRGUARD");
  
  u8g2.setFont(u8g2_font_6x10_tf);
  u8g2.drawStr(16, 40, "Sensor MQ-135");
  u8g2.drawStr(10, 56, "Iniciando PPM...");
  u8g2.sendBuffer();
  delay(2000);
}

void loop() {
  // 1. Promedio de muestras analógicas
  long suma = 0;
  for (int i = 0; i < 15; i++) {
    suma += analogRead(PIN_MQ135);
    delay(10);
  }
  float rawADC = suma / 15.0;

  // 2. Estimación de PPM
  float vOut = (rawADC / 4095.0) * V_REF;
  if (vOut <= 0.1) vOut = 0.1;
  float Rs = ((V_REF - vOut) / vOut) * RL;
  
  float ratio = Rs / Ro;
  float ppm = 116.60 * pow(ratio, -2.76); 

  if (ppm < 350.0) ppm = 350.0 + (rawADC * 0.1);
  if (ppm > 5000.0) ppm = 5000.0;

  // 3. Salida para Serial Plotter en PC
  Serial.print("PPM:");
  Serial.print(ppm);
  Serial.print(" ");
  Serial.print("Umbral_Peligro:");
  Serial.println(1500);

  // 4. Clasificación cualitativa
  String calidad = "";
  if (ppm < 800) {
    calidad = "BUENA";
  } else if (ppm >= 800 && ppm < 1600) {
    calidad = "REGULAR";
  } else {
    calidad = "PELIGRO!";
  }

  // 5. Dibujar en la pantalla OLED
  u8g2.clearBuffer();

  // Marco exterior
  u8g2.drawFrame(0, 0, 128, 64);

  // Título
  u8g2.setFont(u8g2_font_6x10_tf);
  u8g2.drawStr(8, 12, "AIRGUARD - SENSOR");
  u8g2.drawHLine(0, 16, 128);

  // Estado del aire
  u8g2.drawStr(8, 30, "Estado:");
  u8g2.setFont(u8g2_font_ncenB10_tr);
  u8g2.drawStr(56, 30, calidad.c_str());

  // Concentración numérica
  u8g2.setFont(u8g2_font_6x10_tf);
  u8g2.drawStr(8, 44, "Concentracion:");
  
  u8g2.setFont(u8g2_font_ncenB12_tr);
  char bufferPPM[10];
  sprintf(bufferPPM, "%d", (int)ppm);
  u8g2.drawStr(8, 60, bufferPPM);
  
  u8g2.setFont(u8g2_font_6x10_tf);
  u8g2.drawStr(70, 60, "PPM");

  // Enviar imagen a la pantalla
  u8g2.sendBuffer();
  delay(200);
}

